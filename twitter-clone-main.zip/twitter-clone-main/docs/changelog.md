# Changelog

- `Version 1.0.0`:
  - Added a authentication feature (login, signup, demo)
  - Created new assets (logo ... etc.) with Photoshop
  - Created a config entry file which holds the settings files ... etc.
  - Created a explore feature named "hashtag"
  - Created a home feature that holds the main values such as tweet, main feed
  - Created a notification feature that notifies the users
  - Created a profile and profile settings
  - Created basic build and run scripts
