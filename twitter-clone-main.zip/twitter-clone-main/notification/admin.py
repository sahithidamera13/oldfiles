from django.contrib import admin
from .models import NotificationLike

# Register your models here.
admin.site.register(NotificationLike)
