from django.test import TestCase
from django.contrib.auth.models import User
from .models import NotificationLike

# Testing the notifications 
