package com.server.main.exception;

import java.util.Date;

public class ExceptionResponse {

	public ExceptionResponse(Date date, String message, String description) {
		// TODO Auto-generated constructor stub
	}

}
